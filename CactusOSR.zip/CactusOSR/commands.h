#ifndef COMMANDS_H
#define COMMANDS_H

void execute_command(const char* input);

#endif
