#include <stdint.h>
#include <stdbool.h>

/* =============== PORT I/O =============== */

static inline uint8_t inb(uint16_t port)
{
    uint8_t r;
    __asm__ volatile("inb %1, %0" : "=a"(r) : "Nd"(port));
    return r;
}

static inline void outb(uint16_t port, uint8_t val)
{
    __asm__ volatile("outb %0, %1" : : "a"(val), "Nd"(port));
}
/* ============================================
   ACPI REAL HARDWARE SHUTDOWN
   ============================================ */

struct RSDPDescriptor {
    char signature[8];
    uint8_t checksum;
    char oemid[6];
    uint8_t revision;
    uint32_t rsdt_address;
} __attribute__((packed));

struct FACP {
    char signature[4];
    uint32_t length;

    uint8_t unneeded1[76 - 8];
    uint32_t pm1a_control_block;
    uint32_t pm1b_control_block;

    uint8_t unneeded2[112 - 84];
    uint16_t pm1_control_length;

} __attribute__((packed));

static uint32_t *acpi_find_rsdp() {
    for (uint32_t addr = 0xE0000; addr < 0x100000; addr += 16) {
        if (*(uint64_t*)addr == 0x2052545020445352)  // "RSD PTR "
            return (uint32_t*)addr;
    }
    return 0;
}

static struct FACP* acpi_find_fadt() {
    struct RSDPDescriptor* rsdp = (struct RSDPDescriptor*)acpi_find_rsdp();
    if (!rsdp) return 0;

    uint32_t* rsdt = (uint32_t*)(rsdp->rsdt_address);
    int entries = (rsdt[1] - 36) / 4;

    for (int i = 0; i < entries; i++) {
        char* sig = (char*)(rsdt[2 + i]);
        if (sig[0]=='F' && sig[1]=='A' && sig[2]=='C' && sig[3]=='P')
            return (struct FACP*)(rsdt[2 + i]);
    }

    return 0;
}

static void acpi_shutdown() {
    struct FACP* facp = acpi_find_fadt();
    if (!facp) return;  // ACPI not found

    uint32_t pm1a = facp->pm1a_control_block;
    uint32_t pm1b = facp->pm1b_control_block;

    // SLP_TYP = 5 (soft-off), SLP_EN = (1 << 13)
    uint16_t value = (5 << 10) | (1 << 13);

    outb(pm1a, value & 0xFF);
    outb(pm1a + 1, value >> 8);

    if (pm1b) {
        outb(pm1b, value & 0xFF);
        outb(pm1b + 1, value >> 8);
    }
}


/* =============== VGA =============== */

#define VGA_WIDTH 80
#define VGA_HEIGHT 25
#define VGA ((uint16_t*)0xB8000)

int cursor_x = 0, cursor_y = 0;
uint8_t vga_color = 0x07;   // default: light grey on black

static void vga_move()
{
    uint16_t pos = cursor_y * VGA_WIDTH + cursor_x;

    outb(0x3D4, 0x0F);
    outb(0x3D5, pos & 0xFF);

    outb(0x3D4, 0x0E);
    outb(0x3D5, (pos >> 8) & 0xFF);
}

static void vga_put_char(char c)
{
    if (c == '\n') {
        cursor_x = 0;
        cursor_y++;
        vga_move();
        return;
    }

    if (c == '\b') {
        if (cursor_x > 0) {
            cursor_x--;
            VGA[cursor_y * VGA_WIDTH + cursor_x] =
                (vga_color << 8) | ' ';
            vga_move();
        }
        return;
    }

    VGA[cursor_y * VGA_WIDTH + cursor_x] =
        (vga_color << 8) | c;

    cursor_x++;
    if (cursor_x >= VGA_WIDTH) {
        cursor_x = 0;
        cursor_y++;
    }

    vga_move();
}

static void vga_print(const char* s)
{
    while (*s) vga_put_char(*s++);
}

static void vga_clear()
{
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++)
        VGA[i] = (vga_color << 8) | ' ';

    cursor_x = 0;
    cursor_y = 0;
    vga_move();
}

/* =============== KEYBOARD =============== */

static bool shift = false;
static bool caps  = false;

static const char keymap[128] = {
    0,27,'1','2','3','4','5','6','7','8','9','0','-','=', '\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',0,
    'a','s','d','f','g','h','j','k','l',';','\'','`',0,'\\',
    'z','x','c','v','b','n','m',',','.','/',0,'*',0,' ',0
};

static const char keymap_shift[128] = {
    0,0,'!','@','#','$','%','^','&','*','(',')','_','+', '\b',
    '\t','Q','W','E','R','T','Y','U','I','O','P','{','}','\n',0,
    'A','S','D','F','G','H','J','K','L',':','"','~',0,'|',
    'Z','X','C','V','B','N','M','<','>','?',0,'*',0,' ',0
};

static char keyboard_get()
{
    if (!(inb(0x64) & 1)) return 0;

    uint8_t sc = inb(0x60);

    if (sc == 0xE0) return 0;

    // key release
    if (sc & 0x80) {
        sc &= 0x7F;
        if (sc == 0x2A || sc == 0x36) shift = false;
        return 0;
    }

    // shifts
    if (sc == 0x2A || sc == 0x36) { shift = true; return 0; }

    // caps
    if (sc == 0x3A) { caps = !caps; return 0; }

    // ENTER key
    if (sc == 0x1C) return '\n';

    char c = keymap[sc];
    if (!c) return 0;

    bool letter = (c >= 'a' && c <= 'z');

    if (letter) {
        if (shift ^ caps) c -= 32;
        return c;
    }

    if (shift) return keymap_shift[sc];

    return c;
}

/* =============== STRING FUNCTIONS =============== */

int strcmp(const char* a, const char* b)
{
    while (*a && (*a == *b)) {
        a++; b++;
    }
    return (unsigned char)*a - (unsigned char)*b;
}

int strncmp(const char* a, const char* b, int n)
{
    for (int i = 0; i < n; i++)
        if (a[i] != b[i] || !a[i] || !b[i])
            return (unsigned char)a[i] - (unsigned char)b[i];
    return 0;
}

/* =============== COMMAND HANDLER =============== */

static char input[128];
static int len = 0;

static void execute_command()
{
    input[len] = 0; // null terminate

    if (strcmp(input, "help") == 0) {
        vga_print("    help_advanced\n    clear\n    echo <txt>\n    version\n    color <0-15>\n    reboot/poweroff\n");
    }
    else if (strcmp(input, "clear") == 0) {
        vga_clear();
    }
    else if (strncmp(input, "echo ", 5) == 0) {
        vga_print(input + 5);
        vga_print("\n");
        vga_print(input + 5);
        vga_print("\n");
    }
    else if (strcmp(input, "version") == 0) {
        vga_print("CactusOSR 0.1\n");
    }
    else if (strcmp(input, "reboot") == 0) {
        vga_print("Rebooting...\n");
        outb(0x64, 0xFE);   // Reset command to PS/2 controller
    }
    else if (strcmp(input, "poweroff") == 0) {
        vga_print("Powering off...\n");
        acpi_shutdown();
        vga_print("Poweroff failed. Are you on qemu?\n    qemu can't shutdown unless force close");
    }
    else if (strncmp(input, "color ", 6) == 0) {
        int fg = input[6] - '0';
        if (fg >= 0 && fg <= 15) {
            vga_color = fg;
            vga_print("Color changed.\n");
        } else {
            vga_print("Invalid color.\n");
        }
    }
    else {
        vga_print("Unknown command: ");
        vga_print(input);
        vga_print("\n");
    }

    // reset buffer
    for (int i = 0; i < 128; i++) input[i] = 0;
    len = 0;
}

/* =============== KERNEL ENTRY =============== */

void kernel_main()
{
    vga_clear();
    vga_print("CactusOSR 0.1\nType 'help' for commands.\n> ");

    while (1)
    {
        char c = keyboard_get();
        if (!c) continue;

        if (c == '\n') {
            vga_put_char('\n');
            execute_command();
            vga_print("> ");
        }
        else if (c == '\b') {
            if (len > 0) {
                len--;
                vga_put_char('\b');
            }
        }
        else if (len < 127) {
            input[len++] = c;
            vga_put_char(c);
        }
    }
}
